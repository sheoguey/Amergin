comment = "Ruby is fun!"
puts comment.upcase

3.times do
  puts comment.upcase
end

puts Time.new
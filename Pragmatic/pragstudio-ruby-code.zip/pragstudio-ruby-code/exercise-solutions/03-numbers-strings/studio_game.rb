name1 = 'larry'
health1 = 60

puts "#{name1}'s health is #{health1}"
puts "#{name1}'s health is #{health1 * 2}"
puts "#{name1}'s health #{health1 / 9.0}"
puts "#{name1}'s health #{health1 / 9}"

puts "Players: \n\tlarry\n\tmoe\n\tcurly"

# or you could assign the names to variables:

name1 = 'larry'
name2 = 'moe'
name3 = 'curly'

puts "Players: \n\t#{name1}\n\t#{name2}\n\t#{name3}"